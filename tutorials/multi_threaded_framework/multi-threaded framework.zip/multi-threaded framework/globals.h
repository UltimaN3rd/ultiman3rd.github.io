#pragma once

#define RESOLUTION_WIDTH 320
#define RESOLUTION_HEIGHT 180

#define BALL_COUNT 150
#define BALL_RADIUS 4

#include <stdint.h>
#include <stdbool.h>
#include <float.h>
#include <math.h>
#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679
#endif
#define TWOPI (M_PI + M_PI)
#define HALFPI (M_PI / 2.0)
#define QUARTERPI (M_PI / 4.0)
#include <stdio.h>
#include <assert.h>

#include "zen_timer.h"

#if RAND_MAX == 32767
#define rand32() ((rand() << 16) + (rand() << 1) + (rand() & 1))
#define RAND32_MAX 2147483648
#else
#define rand32() rand()
#define RAND32_MAX RAND_MAX
#endif

#define PRINT_ERROR(a, args...) printf("ERROR %s() %s Line %d: " a "\n", __FUNCTION__, __FILE__, __LINE__, ##args);

enum { MOUSE_LEFT = 0b1, MOUSE_MIDDLE = 0b10, MOUSE_RIGHT = 0b100, MOUSE_X1 = 0b1000, MOUSE_X2 = 0b10000 };

// ************************************
// Data
// ************************************

typedef struct {
	union { int width,  w; };
	union { int height, h; };
	union { uint32_t *pixels, *p; };
} sprite_t;

// Render-specific structures

typedef struct {
	float x, y;
} ball_render_t;

typedef struct {
	bool busy;
	uint64_t update_count;
	ball_render_t balls[BALL_COUNT];
} render_state_t;

typedef struct {
	bool *quit;
	_Atomic bool *update_render_swap_state_atom;
	render_state_t *render_states;
	HWND *window_handle;
	sprite_t *frame;
	uint32_t ball_color[BALL_COUNT];
} render_data_t;

// Update-specific structures

typedef struct {
	float x, y, vx, vy;
} ball_update_t;

typedef struct {
	bool *quit;
	_Atomic bool *update_render_swap_state_atom;
	render_state_t *render_states;
	bool *source_keyboard;
	ball_update_t balls[BALL_COUNT];
} update_data_t;

// ************************************
// Functions
// ************************************

int rand_range(int min, int max) {
	return rand32()%(max - min + 1) + min;
}

float randf_range(float min, float max) {
	return (max - min) * ((float)rand32() / (float)RAND32_MAX) + min;
}

