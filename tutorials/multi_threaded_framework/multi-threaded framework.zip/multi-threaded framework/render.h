#pragma once

#include "globals.h"

void DrawCircle(sprite_t *destination, int center_x, int center_y, float radius, uint32_t color);

void Render(void *data_void) {
	render_data_t *data = (render_data_t*)data_void;

	static uint16_t screen_refresh;
	screen_refresh = GetDeviceCaps(CreateCompatibleDC(NULL), VREFRESH);
	printf("Screen refresh rate: %d\n", screen_refresh);

	static LARGE_INTEGER tick_rate, ticks_last, ticks_now;
	static uint64_t ticks_per_frame;
	QueryPerformanceFrequency(&tick_rate);
	ticks_per_frame = tick_rate.QuadPart / screen_refresh; // Update rate = screen refresh rate
	QueryPerformanceCounter(&ticks_last);

	for(int i = 0; i < BALL_COUNT; ++i) {
		data->ball_color[i] = rand32();
	}

	while(!*data->quit) {
		// Wait until WM_PAINT message has been processed. Usually instant.
		UpdateWindow(*data->window_handle);

		/**********************************************
		 * Stateless rendering
		 **********************************************/

		// Clear frame
		memset(data->frame->p, 0, data->frame->w*data->frame->h*4);

		// Select most recently updated render state for this render
		static render_state_t *render_state;
		{
			int found = -1;
			uint64_t highest_update_count = 0;

			while(!__sync_bool_compare_and_swap(data->update_render_swap_state_atom, false, true));

			for(int i = 0; i < 3; ++i) {
				if(!data->render_states[i].busy && data->render_states[i].update_count > highest_update_count) {
					found = i;
					highest_update_count = data->render_states[i].update_count;
				}
			}

			render_state = &data->render_states[found];
			render_state->busy = true;

			*data->update_render_swap_state_atom = false;
		}

		/**********************************************
		 * State-based rendering
		 **********************************************/

		// Draw balls
		for(int i = 0; i < BALL_COUNT; ++i) {
			DrawCircle(data->frame, (int)render_state->balls[i].x, (int)render_state->balls[i].y, BALL_RADIUS-1, data->ball_color[i]);
		}

		render_state->busy = false;

		/**********************************************
		 * Present frame and wait for next screen refresh
		 **********************************************/
		// Update window
		InvalidateRect(*data->window_handle, NULL, FALSE);

		// Sleep until next frame
		QueryPerformanceCounter(&ticks_now);
		static int32_t sleep_time;
		sleep_time = (1000 * ((ticks_last.QuadPart + ticks_per_frame) - ticks_now.QuadPart) / tick_rate.QuadPart) - 2;
		printf("Render sleep: %dms\n\n", sleep_time);
		if(sleep_time > 0) Sleep(sleep_time);

		// Micro-sleep the remaining time
		QueryPerformanceCounter(&ticks_now);
		while(ticks_now.QuadPart - ticks_last.QuadPart < ticks_per_frame) {
			Sleep(0);
			QueryPerformanceCounter(&ticks_now);
		}

		ticks_last.QuadPart += ticks_per_frame;
		if(ticks_now.QuadPart - ticks_last.QuadPart > ticks_per_frame) ticks_last = ticks_now;
	}
}

void DrawCircle(sprite_t *destination, int center_x, int center_y, float radius, uint32_t color) {
	float d;
	int x, y;
	d = 3.f - (2.f*radius);
	x = 0;
	y = radius;
	while(x <= y) {
		for(int i = (center_x-x); i <= (center_x+x); ++i) {
			destination->p[i + (center_y+y)*destination->w] = color;
			destination->p[i + (center_y-y)*destination->w] = color;
		}
		for(int i = (center_x-y); i <= (center_x+y); ++i) {
			destination->p[i + (center_y+x)*destination->w] = color;
			destination->p[i + (center_y-x)*destination->w] = color;
		}
		if(d < 0) { d += 4*x     +  6; ++x; }
		else      { d += 4*(x-y) + 10; ++x; --y; }
	}
}

