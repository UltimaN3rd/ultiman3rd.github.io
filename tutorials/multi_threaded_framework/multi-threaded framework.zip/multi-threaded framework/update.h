#pragma once

#include "globals.h"

void Update(void *data_void) {
	update_data_t *data = (update_data_t*)data_void;

	static LARGE_INTEGER tick_rate, ticks_last, ticks_now;
	static uint64_t ticks_per_frame;
	QueryPerformanceFrequency(&tick_rate);
	ticks_per_frame = tick_rate.QuadPart / 120; // Update rate = 120Hz
	QueryPerformanceCounter(&ticks_last);

	static uint64_t update_count = 0;
	static bool keyboard[256];

	while(!*data->quit) {
		// Capture current keyboard state
		memcpy(keyboard, data->source_keyboard, 256);

		/****************************************************
		 * Game logic
		 ****************************************************/

		if(!keyboard['S']) { // Pause the simulation with [S] key
		for(int i = 0; i < BALL_COUNT; ++i) {
			data->balls[i].x += data->balls[i].vx;
			if((int)data->balls[i].x > RESOLUTION_WIDTH - BALL_RADIUS) {
				data->balls[i].x = RESOLUTION_WIDTH - BALL_RADIUS;
				data->balls[i].vx = -data->balls[i].vx;
			}
			if(data->balls[i].x < BALL_RADIUS) {
				data->balls[i].x = BALL_RADIUS;
				data->balls[i].vx = -data->balls[i].vx;
			}
			data->balls[i].vy -= 0.005f;
			data->balls[i].y += data->balls[i].vy;
			if((int)data->balls[i].y > RESOLUTION_HEIGHT - BALL_RADIUS) {
				data->balls[i].y = RESOLUTION_HEIGHT - BALL_RADIUS;
				data->balls[i].vy = -data->balls[i].vy;
			}
			if(data->balls[i].y < BALL_RADIUS) {
				data->balls[i].y = BALL_RADIUS;
				data->balls[i].vy = -data->balls[i].vy;
			}
			float x, y, ball1angle, ball2angle, ball1velocity, ball2velocity, ball1collisionangle, ball2collisionangle;
			ball_update_t *ball1, *ball2;
			ball1 = &data->balls[i];
			for(int j = i+1; j < BALL_COUNT; ++j) {
				ball2 = &data->balls[j];
				x = ball1->x - ball2->x;
				y = ball1->y - ball2->y;
				if(sqrt(x*x + y*y) < BALL_RADIUS*2) {
					ball1angle = atan2(ball1->vy, ball1->vx);
					ball1velocity = sqrt(ball1->vx*ball1->vx + ball1->vy*ball1->vy);
					ball2angle = atan2(ball2->vy, ball2->vx);
					ball2velocity = sqrt(ball2->vx*ball2->vx + ball2->vy*ball2->vy);
					ball1collisionangle = atan2(ball1->y - ball2->y, ball1->x - ball2->x);
					ball2collisionangle = atan2(ball2->y - ball1->y, ball2->x - ball1->x);
					ball1angle = ball1collisionangle + (ball1collisionangle - ball1angle);
					ball2angle = ball2collisionangle + (ball2collisionangle - ball2angle);

					ball1->vx = -cos(ball1angle) * ball1velocity;
					ball1->vy = -sin(ball1angle) * ball1velocity;
					ball2->vx = -cos(ball2angle) * ball2velocity;
					ball2->vy = -sin(ball2angle) * ball2velocity;

					static bool swapper = false;
					do {
						if(swapper) {
							if(ball1->x < ball2->x) {
								--ball1->x;
								if(ball1->x < BALL_RADIUS) {
									ball1->x = BALL_RADIUS;
									++ball2->x;
								}
							} else {
								--ball2->x;
								if(ball2->x < BALL_RADIUS) {
									ball2->x = BALL_RADIUS;
									++ball1->x;
								}
							}

							if(ball1->y < ball2->y) {
								--ball1->y;
								if(ball1->y < BALL_RADIUS) {
									ball1->y = BALL_RADIUS;
									++ball2->y;
								}
							} else {
								--ball2->y;
								if(ball2->y < BALL_RADIUS) {
									ball2->y = BALL_RADIUS;
									++ball1->y;
								}
							}
						} else {
							if(ball1->x > ball2->x) {
								++ball1->x;
								if(ball1->x > RESOLUTION_WIDTH - BALL_RADIUS) {
									ball1->x = RESOLUTION_WIDTH - BALL_RADIUS;
									--ball2->x;
								}
							} else {
								++ball2->x;
								if(ball2->x > RESOLUTION_WIDTH - BALL_RADIUS) {
									ball2->x = RESOLUTION_WIDTH - BALL_RADIUS;
									--ball1->x;
								}
							}

							if(ball1->y > ball2->y) {
								++ball1->y;
								if(ball1->y > RESOLUTION_HEIGHT - BALL_RADIUS) {
									ball1->y = RESOLUTION_HEIGHT - BALL_RADIUS;
									--ball2->y;
								}
							} else {
								++ball2->y;
								if(ball2->y > RESOLUTION_HEIGHT - BALL_RADIUS) {
									ball2->y = RESOLUTION_HEIGHT - BALL_RADIUS;
									--ball1->y;
								}
							}
						}
						x = ball1->x - ball2->x;
						y = ball1->y - ball2->y;
						swapper = !swapper;
					} while(sqrt(x*x + y*y) < BALL_RADIUS*2);
				}
			}
		}
		}

		// Create a render state based on current game state
		{	// Select oldest non-busy render state to replace
			static int found;
			static uint64_t lowest_update_count;
			found = -1;
			lowest_update_count = -1;

			while(!__sync_bool_compare_and_swap(data->update_render_swap_state_atom, false, true));

			for(int i = 0; i < 3; ++i) {
				if(!data->render_states[i].busy && data->render_states[i].update_count < lowest_update_count) {
					found = i;
					lowest_update_count = data->render_states[i].update_count;
				}
			}

			static render_state_t *render_state;
			render_state = &data->render_states[found];
			render_state->busy = true;

			*data->update_render_swap_state_atom = false;

			render_state->update_count = ++update_count;

			for(int i = 0; i < BALL_COUNT; ++i) {
				render_state->balls[i].x = data->balls[i].x;
				render_state->balls[i].y = data->balls[i].y;
			}

			render_state->busy = false;
		}

		// Sleep until next frame
		QueryPerformanceCounter(&ticks_now);
		static int32_t sleep_time;
		sleep_time = (1000.f * ((ticks_last.QuadPart + ticks_per_frame) - ticks_now.QuadPart) / tick_rate.QuadPart) - 2;
		printf("Update sleep: %dms\n", sleep_time);
		if(sleep_time > 0) Sleep(sleep_time);

		// Micro-sleep the remaining time
		QueryPerformanceCounter(&ticks_now);
		while(ticks_now.QuadPart - ticks_last.QuadPart < ticks_per_frame) {
			Sleep(0);
			QueryPerformanceCounter(&ticks_now);
		}

		ticks_last.QuadPart += ticks_per_frame;
		if(ticks_now.QuadPart - ticks_last.QuadPart > ticks_per_frame) ticks_last = ticks_now;
	}
}

