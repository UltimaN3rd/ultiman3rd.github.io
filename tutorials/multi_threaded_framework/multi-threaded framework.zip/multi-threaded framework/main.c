#define UNICODE
#define _UNICODE

#include "globals.h"

#include "render.h"
#include "update.h"

#include <windows.h>
#include <uxtheme.h>
#include <process.h>
#include "NtSetTimerResolution.h"

static bool quit = false;

// Window drawing variables
static HWND window_handle;
static BITMAPINFO bitmap_info;
static HBRUSH background_brush;

static uint32_t pixels[RESOLUTION_WIDTH*RESOLUTION_HEIGHT];
static sprite_t frame = {.w=RESOLUTION_WIDTH, .h=RESOLUTION_HEIGHT, .p=pixels};
static int scale, left, bottom;
static render_state_t render_states[3] = {0};
static _Atomic bool update_render_swap_state_atom;

static bool keyboard[256] = {0};
static struct {
	int x, y;
	uint8_t buttons;
} mouse;

static uintptr_t thread_render, thread_update;

static render_data_t render_data = {
	.quit = &quit,
	.update_render_swap_state_atom = &update_render_swap_state_atom,
	.render_states = render_states,
	.window_handle = &window_handle,
	.frame = &frame,
};

static update_data_t update_data = {
	.quit = &quit,
	.update_render_swap_state_atom = &update_render_swap_state_atom,
	.source_keyboard = keyboard,
	.render_states = render_states,
};

LRESULT CALLBACK WindowProcessMessage(HWND window_handle, UINT message, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR pCmdLine, int nCmdShow) {

	BufferedPaintInit();
	ZenTimer_Init();
	{ ULONG time; NtSetTimerResolution(1000, TRUE, &time); }
	{ LARGE_INTEGER qpc; QueryPerformanceCounter(&qpc);	srand(qpc.LowPart);	}

	// Register window class
	const wchar_t window_class_name[] = L"Window Class";
	static WNDCLASS window_class = { 0 };
	window_class.lpfnWndProc = WindowProcessMessage;
	window_class.hInstance = hInstance;
	window_class.lpszClassName = window_class_name;
	RegisterClass(&window_class);

	// Prepare bitmap_info for screen blitting
	bitmap_info.bmiHeader.biSize = sizeof(bitmap_info.bmiHeader);
	bitmap_info.bmiHeader.biPlanes = 1;
	bitmap_info.bmiHeader.biBitCount = 32;
	bitmap_info.bmiHeader.biCompression = BI_RGB;
	bitmap_info.bmiHeader.biWidth = RESOLUTION_WIDTH;
	bitmap_info.bmiHeader.biHeight = RESOLUTION_HEIGHT;
	background_brush = (HBRUSH)GetStockObject(GRAY_BRUSH);

	// Open fullscreen borderless window
	{
		RECT desktop_rect;
		HWND desktop_handle = GetDesktopWindow();
		if(desktop_handle) GetWindowRect(desktop_handle, &desktop_rect);
		else { desktop_rect.left = 0; desktop_rect.top = 0; desktop_rect.right = 800; desktop_rect.bottom = 600; }
		// Create window
		window_handle = CreateWindow(window_class_name, L"Program Framework", WS_POPUP | WS_VISIBLE, desktop_rect.left,desktop_rect.top, desktop_rect.right-desktop_rect.left,desktop_rect.bottom-desktop_rect.top, NULL, NULL, hInstance, NULL);
	}
	if(window_handle == NULL) {
		PRINT_ERROR("CreateWindow() failed. Returned NULL.\n");
		return -1;
	}

	// Setup initial simulation state
	for(int i = 0; i < BALL_COUNT; ++i) {
		update_data.balls[i].x  = randf_range(BALL_RADIUS, RESOLUTION_WIDTH  - BALL_RADIUS);
		update_data.balls[i].y  = randf_range(30, RESOLUTION_HEIGHT - BALL_RADIUS);
		update_data.balls[i].vx = randf_range(-0.5f, 0.5f);
		update_data.balls[i].vy = randf_range(-0.5f, 0.5f);
	}

	// Start system threads
	if((thread_update = _beginthread(&Update, 0, (void*)&update_data)) == -1ul) {
		PRINT_ERROR("_beginthread(update) failed.");
		return -1;
	}

	if((thread_render = _beginthread(Render, 0, (void*)&render_data)) == -1ul) {
		PRINT_ERROR("_beginthread(render) failed.");
		return -1;
	}

	static MSG message = { 0 };
	while(GetMessage(&message, NULL, 0, 0) != 0 && !quit) { DispatchMessage(&message);  }

	{ ULONG time; NtSetTimerResolution(0, FALSE, &time); }

	return 0;
}

LRESULT CALLBACK WindowProcessMessage(HWND window_handle, UINT message, WPARAM wParam, LPARAM lParam) {
	static bool has_focus = true;
	static int16_t window_width, window_height;

	switch(message) {
		case WM_QUIT:
		case WM_DESTROY: {
			quit = true;
		} break;

		case WM_PAINT: {
			static HDC device_context;
			static PAINTSTRUCT paint;
			device_context = BeginPaint(window_handle, &paint);

			static HDC buffered_device_context;
			static HPAINTBUFFER paint_buffer;
			paint_buffer = BeginBufferedPaint(device_context, &paint.rcPaint, BPBF_DIB, NULL, &buffered_device_context);

			FillRect(buffered_device_context, &paint.rcPaint, background_brush);
			StretchDIBits(buffered_device_context, left, bottom, RESOLUTION_WIDTH * scale, RESOLUTION_HEIGHT * scale, 0, 0, RESOLUTION_WIDTH, RESOLUTION_HEIGHT, frame.p, &bitmap_info, DIB_RGB_COLORS, SRCCOPY);

			EndBufferedPaint(paint_buffer, TRUE);

			EndPaint(window_handle,&paint);
		} break;

		case WM_SIZE: {
			window_width  = LOWORD(lParam);
			window_height = HIWORD(lParam);
			scale = min(window_width / RESOLUTION_WIDTH, window_height / RESOLUTION_HEIGHT);
			left   = (window_width - RESOLUTION_WIDTH  * scale) / 2;
			bottom = (window_height - RESOLUTION_HEIGHT * scale) / 2;
		} break;

		case WM_KILLFOCUS: {
			has_focus = false;
			memset(keyboard, 0, 256 * sizeof(keyboard[0]));
			mouse.buttons = 0;
		} break;

		case WM_SETFOCUS: has_focus = true; break;

		case WM_SYSKEYDOWN:
		case WM_SYSKEYUP:
		case WM_KEYDOWN:
		case WM_KEYUP: {
			if(has_focus) {
				static bool key_is_down, key_was_down;
				key_is_down  = ((lParam & (1 << 31)) == 0);
				key_was_down = ((lParam & (1 << 30)) != 0);
				if(key_is_down != key_was_down) {
					keyboard[(uint8_t)wParam] = key_is_down;
					if(key_is_down) {
						switch(wParam) {
							case VK_ESCAPE: quit = true; break;
						}
					}
				}
			}
		} break;

		case WM_MOUSEMOVE: {
			mouse.x = LOWORD(lParam);
			mouse.y = frame.h - 1 - HIWORD(lParam);
		} break;

		case WM_LBUTTONDOWN: mouse.buttons |=  MOUSE_LEFT;   break;
		case WM_LBUTTONUP:   mouse.buttons &= ~MOUSE_LEFT;   break;
		case WM_MBUTTONDOWN: mouse.buttons |=  MOUSE_MIDDLE; break;
		case WM_MBUTTONUP:   mouse.buttons &= ~MOUSE_MIDDLE; break;
		case WM_RBUTTONDOWN: mouse.buttons |=  MOUSE_RIGHT;  break;
		case WM_RBUTTONUP:   mouse.buttons &= ~MOUSE_RIGHT;  break;

		case WM_XBUTTONDOWN: {
			if(GET_XBUTTON_WPARAM(wParam) == XBUTTON1) {
				mouse.buttons |= MOUSE_X1;
			} else { mouse.buttons |= MOUSE_X2; }
		} break;
		case WM_XBUTTONUP: {
			if(GET_XBUTTON_WPARAM(wParam) == XBUTTON1) {
				mouse.buttons &= ~MOUSE_X1;
			} else { mouse.buttons &= ~MOUSE_X2; }
		} break;

		case WM_MOUSEWHEEL: {
			//printf("%s\n", wParam & 0b10000000000000000000000000000000 ? "Down" : "Up");
		} break;

		default: return DefWindowProc(window_handle, message, wParam, lParam);
	}
	return 0;
}

