gcc -ggdb -Wall -Werror -Wno-unused-variable -Wno-unused-but-set-variable -Wno-unused-function -o a.out main.c -Ilibraries/ -lX11 -lXrender -lGLU -lGL -lXext -lm -lXfixes
