#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#include "utilities.h"

#define OSINTERFACE_LINUX_USE_OPENGL
#define OSINTERFACE_WINDOWS_USE_OPENGL
#define OSINTERFACE_FRAME_BUFFER_SCALED
#include "osinterface.h"

#include "bitmap_font.h"

#define FRAME_WIDTH 1000
#define FRAME_HEIGHT 700
uint32_t pixels[FRAME_WIDTH * FRAME_HEIGHT];
sprite_t frame = {
	.w = FRAME_WIDTH, .h = FRAME_HEIGHT,
	.pixels = (pixel_t*)pixels,
};

int main (int argc, char **argv) {
	os_SetWindowFrameBuffer (pixels, frame.w, frame.h);

	EXIT_IF (!os_Init ("Hello world"));
	os_WindowSize (FRAME_WIDTH, FRAME_HEIGHT);

	font_t font;
	EXIT_IF (!font_Load (&font, "nick's font"));

	bool quit = false;
	while (!quit) {
		os_WaitForScreenRefresh ();
		os_uSleepEfficient (10000);

		os_event_t e;
		do {
			e = os_NextEvent();
			switch (e.type) {
				case os_EVENT_QUIT: {
					quit = true;
					exit (e.exit_code);
				}

				case os_EVENT_KEY_PRESS: {
					switch (e.key) {
						case os_KEY_ESCAPE: {
							os_SendQuitEvent ();
						} break;

						case os_KEY_R: {
							font_Free (&font);
							EXIT_IF (!font_Load (&font, "nicks_bmpfont"));
						} break;

						default: break;
					}
				} break;

				default: break;
			}
		} while (e.type != os_EVENT_NULL);

		memset (frame.pixels, 55, os_private.frame_buffer.width * os_private.frame_buffer.height * sizeof (os_private.frame_buffer.pixels[0]));

		// font_Write (&font, &frame, 5, FRAME_HEIGHT-5, "{|}~\n"
		// 												"qrstuvwxyz\n"
		// 												"ghijklmnop\n"
		// 												"]^_`abcdef\n"
		// 												"STUVWXYZ[\\\n"
		// 												"IJKLMNOPQR\n"
		// 												"?@ABCDEFGH\n"
		// 												"56789:;<=>\n"
		// 												"+,-./01234\n"
		// 												"!\"#$%&'()*\n");

		font_WriteWrap (&font, &frame, 5, FRAME_HEIGHT-5, FRAME_WIDTH-10,
			" Elizabeth was too much embarrassed to say a word. After a short pause, her companion added, \"You are too generous to trifle with me. If your feelings are still what they were last April, tell me so at once. My affections and wishes are unchanged; but one word from you will silence me on this subject for ever.\"\n\n"
			" Elizabeth, feeling all the more than common awkwardness and anxiety of his situation, now forced herself to speak; and immediately, though not very fluently, gave him to understand that her sentiments had undergone so material a change since the period to which he alluded, as to make her receive with gratitude and pleasure his present assurances. The happiness which this reply produced was such as he had probably never felt before; and he expressed himself on the occasion as sensibly and as warmly as a man violently in love can be supposed to do. Had Elizabeth been able to encounter his eyes, she might have seen how well the expression of heartfelt delight diffused over his face became him: but though she could not look she could listen; and he told her of feelings which, in proving of what importance she was to him, made his affection every moment more valuable.");

		os_DrawScreen ();
	}

	return 0;
}