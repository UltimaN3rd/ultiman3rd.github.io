/*

USAGE:

font_t my_font;
font_Load (&my_font, "my/font/folder");
font_Write (&my_font, &target_sprite, 5, target_sprite.h-5, "Hello world!");
font_WriteWrap (&my_font, &target_sprite, 5, target_sprite.h-25, target_sprite.w-5, "Hello world! This is a really long string which will hopefully reach the rightmost edge of the target sprite and wrap down to the next line. By the way, this code was written by Nicholas Walton as part of a programming tutorial video series on YouTube: https://www.youtube.com/playlist?list=PLPGNrHeloF_dOY7ZlCq6D4UwKA-adaQHX");

A bitmap font is a folder which contains the files, [font.bmp OR font.tga] and properties.txt.
The font image must be a 32-bit bmp or targa with alpha channel.
It is 10 rows and columns of characters, each of equal size.
The image must be laid out like so:

{ | } ~
q r s t u v w x y z
g h i j k l m n o p
] ^ _ ` a b c d e f
S T U V W X Y Z [ \
I J K L M N O P Q R
? @ A B C D E F G H
5 6 7 8 9 : ; < = >
+ , - . / 0 1 2 3 4
! " # $ % & ' ( ) *

properties.txt is a series of lines.
Each one starts with the character whose properties are to be edited, followed by a space then each property.
A line that starts with a space is where you can set the font's space width and line height.
Properties have a character followed by the number to set that property.
Currently the only character property is descent.
Properties are listed with the first letter of their name followed by the number, with no space between.
Any character not listed will have a descent of 0.

Example: nicks_bmpfont/properties.txt
 w12 h24
g d9
j d9
p d8
q d9
y d7
^ d-10
` d-11
| d-1
~ d-10
: d-3
; d-2
< d-1
> d-1
= d-3
, d3
" d-8
' d-12
* d-10

*/

#pragma once

#include <stdint.h>
#include <stdbool.h>
#include "sprite.h"
#include "utilities.h"

#define BITMAP_FONT_FIRST_VISIBLE_CHAR 33
#define BITMAP_FONT_LAST_VISIBLE_CHAR 126
#define BITMAP_FONT_NUM_VISIBLE_CHARS (BITMAP_FONT_LAST_VISIBLE_CHAR - BITMAP_FONT_FIRST_VISIBLE_CHAR + 1)

typedef struct {
    int line_height;
    int space_width;
    pixel_t *pixels;
    sprite_t bitmaps[BITMAP_FONT_NUM_VISIBLE_CHARS];
    int8_t descent[BITMAP_FONT_NUM_VISIBLE_CHARS];
} font_t;

// Pass in the folder which contains the font files: font.bmp/tga and properties.txt
// Returns false on failure and true on success
bool font_Load (font_t *font, char *directory) {
    bool return_value = false;

    int directory_length = strlen (directory);
    if (directory_length > 512) {
        PRINT_ERROR ("Directory exceeds 512 characters: %s", directory);
        goto LoadFontReturn;
    }

    char last_char = directory[directory_length-1]; // Go back from the NULL
    bool ending_slash = false;
    if (last_char == '\'' || last_char == '/') {
        ending_slash = true;
    }
    // Copy the directory, adding a slash at the end if it's missing.
    char directory_fixed[513];
    sprintf (directory_fixed, "%s%c", directory, ending_slash ? '\0' : '/');

    char filename[600];
    
    sprintf (filename, "%sfont.bmp", directory_fixed);
    sprite_t bitmap;
    if (!SpriteLoad (&bitmap, filename)) {
        sprintf (filename, "%sfont.tga", directory_fixed);
        if (!SpriteLoad (&bitmap, filename)) {
            PRINT_ERROR ("Failed to load font bitmap: %s. Attempted both .bmp and .tga.", filename);
            goto LoadFontReturn;
        }
    }

    // Convert bitmap to individual character bitmaps
    sprite_t *bmp;
    int width, height;
    width = bitmap.width / 10;
    height = bitmap.height / 10;
    font->space_width = width/2; font->line_height = height + 4; // Just defaults in case they aren't set inside properties.txt
    font->pixels = (pixel_t*) malloc (width * height * BITMAP_FONT_NUM_VISIBLE_CHARS * sizeof (pixel_t));
    if (!font->pixels) {
        PRINT_ERROR ("Failed to allocate font pixels: %s", directory);
        free (bitmap.p);
        goto LoadFontReturn;
    }
    
    int x, y;
    int cumulative_pixels = 0;
    for (int i = 0; i < BITMAP_FONT_NUM_VISIBLE_CHARS; ++i) {
        y = i / 10;
        x = i % 10;
        struct {
            int left, right, bottom, top, width, height;
        } source;

        for (int xx = 0; xx < width; ++xx) {
            for (int yy = 0; yy < height; ++yy) {
                if (bitmap.pixels[(yy + y * height) * bitmap.width + x * width + xx].a != 0) {
                    source.left = xx;
                    yy = height;
                    xx = width;
                }
            }
        }
        for (int xx = width - 1; xx >= 0; --xx) {
            for (int yy = 0; yy < height; ++yy) {
                if (bitmap.pixels[(yy + y * height) * bitmap.width + x * width + xx].a != 0) {
                    source.right = xx;
                    yy = height;
                    xx = -1;
                }
            }
        }
        for (int yy = 0; yy < height; ++yy) {
            for (int xx = 0; xx < width; ++xx) {
                if (bitmap.pixels[(yy + y * height) * bitmap.width + x * width + xx].a != 0) {
                    source.bottom = yy;
                    xx = width;
                    yy = height;
                }
            }
        }
        for (int yy = height-1; yy >= 0; --yy) {
            for (int xx = 0; xx < width; ++xx) {
                if (bitmap.pixels[(yy + y * height) * bitmap.width + x * width + xx].a != 0) {
                    source.top = yy;
                    xx = width;
                    yy = -1;
                }
            }
        }

        source.width = source.right - source.left + 1;
        source.height = source.top - source.bottom + 1;
        bmp = &font->bitmaps[i];
        bmp->w = source.width;
        bmp->h = source.height;
        font->descent[i] = 0;
        
        bmp->p = font->pixels + cumulative_pixels;
        for (int sy = 0; sy < source.height; ++sy) {
            memcpy (&bmp->p[sy * bmp->w], &bitmap.pixels[(sy + source.bottom + y * height) * bitmap.width + x * width + source.left], bmp->w * sizeof(pixel_t));
        }
        cumulative_pixels += bmp->width * bmp->height;
    }

    free (bitmap.p);

    font->pixels = (pixel_t*)realloc (font->pixels, cumulative_pixels * sizeof (pixel_t));
    
    int pixel_offset = 0;
    for (int i = 0; i < BITMAP_FONT_NUM_VISIBLE_CHARS; ++i) {
        font->bitmaps[i].pixels = font->pixels + pixel_offset;
        pixel_offset += font->bitmaps[i].w * font->bitmaps[i].h;
    }

    sprintf (filename, "%sproperties.txt", directory_fixed);

    char *contents;
    contents = ReadEntireFile (filename, NULL);
    if (contents == NULL) {
        PRINT_ERROR ("Failed to read file: %s", filename);
        goto LoadFontReturn;
    }

    char *c = contents;
    int i;
    char property;
    int value;
    while (*c != '\0') {
        i = *c;
        if (i >= BITMAP_FONT_FIRST_VISIBLE_CHAR && i <= BITMAP_FONT_LAST_VISIBLE_CHAR) {
            i -= BITMAP_FONT_FIRST_VISIBLE_CHAR;
            ++c; // Skip the letter to get to the space before first property
            // Now we're at the list of properties for this letter [i]
            do {
                ++c;
                property = *c;
                value = atoi (c+1);
                switch (property) {
                    case 'd': font->descent[i] = value; break;
                    default: {
                        PRINT_ERROR ("Reading font \'%s\' encountered invalid property \'%c\' in line of character \'%c\'", directory, property, (char)(i + BITMAP_FONT_FIRST_VISIBLE_CHAR));
                        goto LoadFontFreeContents;
                    }
                }
                c = StringSkipNonWhiteSpace (c); // Skip the property value
            } while (*c == ' '); // If it's a space, there's another property
            c = StringSkipWhiteSpace (c); // Otherwise we need to get to the next line and the next letter
        }
        else if (*c == ' ') { // Font properties
            do {
                ++c;
                property = *c;
                value = atoi (c+1);
                switch (property) {
                    case 'w': font->space_width = value; break;
                    case 'h': font->line_height = value; break;
                    default: {
                        PRINT_ERROR ("Reading font \'%s\' encountered invalid property \'%c\' in line of font properties (line which starts with space).", directory, property);
                        goto LoadFontFreeContents;
                    }
                }
                c = StringSkipNonWhiteSpace (c); // Skip the property value
            } while (*c == ' '); // If it's a space, there's another property
            c = StringSkipWhiteSpace (c); // Otherwise we need to get to the next line and the next letter
        }
        else {
            PRINT_ERROR ("Invalid font file. Format for each line should always be: \"<ascii character> p<property number>\". Error encountered here: %s", c);
            goto LoadFontFreeContents;
        }
    }

    return_value = true;

LoadFontFreeContents:   free (contents);
LoadFontReturn:         return return_value;
}

static inline void font_Free (font_t *font) {
    free (font->pixels);
}

void font_Write (font_t *font, sprite_t *destination, int left, int top, char *text) {
    char c = *(text++);
    int i;
    int x = left, y = top - font->line_height; // Current x and y, updated as we draw each character
    while (c != '\0') {
        switch (c) {
            case ' ': x += font->space_width; break;

            case '\n': {
                x = left;
                y -= font->line_height;
            } break;

            default: {
                i = c - BITMAP_FONT_FIRST_VISIBLE_CHAR;
                if (i >= 0 && i < BITMAP_FONT_NUM_VISIBLE_CHARS) {
                    BlitAlpha10 (&font->bitmaps[i], destination, x, y - font->descent[i]);
                    x += font->bitmaps[i].width + 1;
                } // If character wasn't in the range, then we ignore it.
            } break;
        }
        c = *(text++);
    }
}

void font_WriteWrap (font_t *font, sprite_t *destination, int left, int top, int right, char *text) {
    char c = *text;
    int i;
    int x = left, y = top - font->line_height; // Current x and y, updated as we draw each character
    bool new_word = true;
    while (c != '\0') {
        i = c - BITMAP_FONT_FIRST_VISIBLE_CHAR;
        if (i >= 0 && i < BITMAP_FONT_NUM_VISIBLE_CHARS) {
            if (new_word) {
                new_word = false;
                int word_width = 0;
                char *word = text;
                do {
                    word_width += font->bitmaps[i].width + 1;
                    i = *(++word) - BITMAP_FONT_FIRST_VISIBLE_CHAR;
                } while (i >= 0 && i < BITMAP_FONT_NUM_VISIBLE_CHARS);
                i = c - BITMAP_FONT_FIRST_VISIBLE_CHAR;
                word_width -= 1; // Don't need the extra pixel on the right of the word
                if (x + word_width > right) { // The word is too wide so we need to start the next line
                    x = left;
                    y -= font->line_height;
                }
            }
            if (!new_word) {
                BlitAlpha10 (&font->bitmaps[i], destination, x, y - font->descent[i]);
                x += font->bitmaps[i].width + 1;
            }
        }
        else { // Character is not in the visible set
            new_word = true;
            switch (c) {
                case ' ': {
                    x += font->space_width;
                } break;
                case '\n': {
                    x = left;
                    y -= font->line_height;
                } break;
                default: break;
            }
        }
        c = *++text;
    }
}