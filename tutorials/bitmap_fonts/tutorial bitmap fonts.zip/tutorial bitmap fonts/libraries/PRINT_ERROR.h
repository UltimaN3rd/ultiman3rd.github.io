#pragma once

#include <stdio.h>
#include <stdlib.h>

#define PRINT_ERROR(a, args...) printf("ERROR %s() %s Line %d: " a "\n", __FUNCTION__, __FILE__, __LINE__, ##args);

// Pass this the expression to evaluate
#define EXIT_IF(a) do { if(a) { PRINT_ERROR(#a); abort(); } } while(0)