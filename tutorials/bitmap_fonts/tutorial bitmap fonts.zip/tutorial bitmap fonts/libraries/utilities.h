#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "PRINT_ERROR.h"

// Returns an allocated char array of the entire file contents.
// YOU MUST DEALLOCATE THE POINTER!
// Prints errors and returns NULL on failure.
char *ReadEntireFile (char *filename, int *return_file_length) {
    char *buffer;
    FILE *file = fopen (filename, "rb");
    if (!file) {
        PRINT_ERROR ("Failed to open file: %s. Maybe it doesn't exist?", filename)
        return NULL;
    }
    fseek (file, 0, SEEK_END);
    int file_length = ftell (file);
    buffer = malloc (file_length+1);
    if (!buffer) {
        PRINT_ERROR ("Failed to allocate memory for file buffer when reading file \"%s\" of length %d", filename, file_length);
        fclose (file);
        return NULL;
    }
    rewind (file);
    int bytes_read = fread (buffer, 1, file_length, file);
    fclose (file);
    if (bytes_read != file_length) {
        PRINT_ERROR ("Failed to read file. Expected to read %d bytes. Read %d bytes.", file_length, bytes_read);
        free (buffer);
        return NULL;
    }
    buffer[file_length] = 0;
    if (return_file_length) *return_file_length = file_length;
    return buffer;
}

// Checks the number of characters of the smaller of the two strings
bool StringsAreTheSame (char *a, char *b) {
    if (*a == '\0' || *b == '\0') return false;
    do {
        if (*a != *b) return false;
    } while (*(++a) != '\0' && *(++b) != '\0');
    return true;
}

static inline char *StringSkipWhiteSpace (char *c) {
	register char a = *c;
	while (a > 0 && (a < 33 || a > 126)) {
		a = *(++c);
	}
	return c;
}

static inline char *StringSkipNonWhiteSpace (char *c) {
	register char a = *c;
	while (a > 0 && (a > 32 && a < 127)) {
		a = *(++c);
	}
	return c;
}

// Iterates over a given number of characters, and if each one is an upper case letter it will be changed to lower case.
static inline void StringDecapitalize (char *c, int number_of_letters_to_decapitalize) {
    while (number_of_letters_to_decapitalize-- && *c)
        if (*c >= 'A' && *c <= 'Z')
            *c += 'a' - 'A';
}

// Iterates over a given number of characters, and if each one is a lower case letter it will be changed to upper case.
static inline void StringCapitalize (char *c, int number_of_letters_to_capitalize) {
    while (number_of_letters_to_capitalize-- && *c)
        if (*c >= 'a' && *c <= 'z')
            *c -= 'a' - 'A';
}