#pragma once

#include "utilities.h"

#pragma push_macro ("max")
#undef max
#pragma push_macro ("min")
#undef min

#define max(a, b) ((a) > (b) ? (a) : (b))
#define min(a, b) ((a) < (b) ? (a) : (b))

typedef struct {
	union {
		struct { uint8_t b, g, r, a; };
		uint32_t u32;
	};
} pixel_t;

typedef struct {
	union { int width,  w; };
	union { int height, h; };
	union { pixel_t *pixels, *p; };
} sprite_t;

bool SpriteLoadBMP(sprite_t *sprite, char *filename) {
	bool return_value = false;

	uint32_t file_size;
	uint32_t image_data_address;
	uint32_t bitmap_header_size;
	int32_t width;
	int32_t height;
	uint32_t pixel_count;
	uint16_t bit_depth;
	uint8_t byte_depth;
	pixel_t *pixels;

	FILE *file;
	file = fopen(filename, "rb");
	if (!file) {
		PRINT_ERROR("(%s) Failed to open file\n", filename);
		return false;
	}

	uint8_t byte;
	if (!fread(&byte, 1, 1, file) || byte != 'B') {
		PRINT_ERROR("(%s) First byte of file is not \"B\"\n", filename);
		goto LoadBMPClose;
	}

	if (!fread(&byte, 1, 1, file) || byte != 'M') {
		PRINT_ERROR("(%s) Second byte of file is not \"M\"\n", filename);
		goto LoadBMPClose;
	}

	fread(&file_size, 4, 1, file);
	fseek(file, 10, SEEK_SET);
	fread(&image_data_address, 4, 1, file);
	fread(&bitmap_header_size, 4, 1, file);
	fread(&width, 4, 1, file);
	fread(&height, 4, 1, file);
	pixel_count = width * height;
	fseek(file, 28, SEEK_SET);
	fread(&bit_depth, 2, 1, file);

	if (bit_depth != 32) {
		PRINT_ERROR("(%s) Bit depth expected %d is %d\n", filename, 32, bit_depth);
		goto LoadBMPClose;
	}

	byte_depth = bit_depth / 8;
	//printf("file size: %d\nimage data address: %d\nbitmap header size: %d\nwidth: %d\nheight: %d\nbit depth: %d\n", file_size, image_data_address, bitmap_header_size, width, height, bit_depth);
	pixels = (pixel_t*)malloc(pixel_count * byte_depth);
	if(!pixels) {
		PRINT_ERROR("(%s) Failed to allocate %d pixels.\n", filename, pixel_count);
		goto LoadBMPClose;
	}

	fseek(file, image_data_address, SEEK_SET);
	uint32_t pixels_read = fread(pixels, byte_depth, pixel_count, file);
	//printf("Read %d pixels\n", pixels_read);
	if(pixels_read != pixel_count) {
		PRINT_ERROR("(%s) Read pixel count incorrect. Is %d expected %d\n", filename, pixels_read, pixel_count);
		free (pixels);
		goto LoadBMPClose;
	}

	sprite->w = width;
	sprite->h = height;
	sprite->p = pixels;
	return_value = true;

LoadBMPClose:
	fclose(file);
	
	return return_value;
}

bool SpriteLoadTGA (sprite_t *sprite, char *filename) {
	char *file_contents = ReadEntireFile (filename, NULL);
	if (!file_contents) {
		PRINT_ERROR ("Failed to read file: %s", filename);
		return false;
	}
	sprite->width = file_contents[13];
	sprite->width <<= 8;
	sprite->width += file_contents[12];
	sprite->height = file_contents[15];
	sprite->height <<= 8;
	sprite->height += file_contents[14];
	sprite->pixels = malloc (sprite->width * sprite->height * sizeof (sprite->pixels[0]));
	if (!sprite->pixels) {
		PRINT_ERROR ("Failed to allocate %dx%d pixels when reading %s", sprite->width, sprite->height, filename);
		free (file_contents);
		return false;
	}
	for (int y = 0; y < sprite->height; ++y) {
		memcpy (&sprite->pixels[y * sprite->width], &file_contents[18 + sprite->width * (sprite->height - 1 - y) * 4], sprite->width * 4);
	}
	free (file_contents);
	return true;
}

// Supports .bmp and .tga
bool SpriteLoad (sprite_t *sprite, char *filename) {
	char *file_type;
	file_type = &filename[strlen(filename) - 3];
	StringDecapitalize (file_type, 3);
	if (StringsAreTheSame (file_type, "bmp")) {
		return SpriteLoadBMP (sprite, filename);
	}
	else if (StringsAreTheSame (file_type, "tga")) {
		return SpriteLoadTGA (sprite, filename);
	}
	PRINT_ERROR ("Error loading sprite \'%s\': file type \'%s\' not supported. Only .bmp and .tga files are supported.", filename, file_type);
	return false;
}

void Blit(sprite_t *source, sprite_t *destination, int x, int y) {
	int left, right, bottom, top;
	left    = max(0, x);
	right   = min(destination->w-1, x+source->w-1);
	bottom  = max(0, y);
	top     = min(destination->h-1, y+source->h-1);
	for(int y2 = bottom; y2 <= top; ++y2) {
		for(int x2 = left; x2 <= right; ++x2) {
			destination->p[x2 + y2*destination->w] = source->p[x2-x + (y2-y)*source->w];
		}
	}
}

void BlitAlpha10(sprite_t *source, sprite_t *destination, int x, int y) {
	int left, right, bottom, top;
	left    = max(0, x);
	right   = min(destination->w-1, x+source->w-1);
	bottom  = max(0, y);
	top     = min(destination->h-1, y+source->h-1);
	for(int y2 = bottom; y2 <= top; ++y2) {
		for(int x2 = left; x2 <= right; ++x2) {
			pixel_t source_pixel = source->p[x2-x + (y2-y)*source->w];
			if (source_pixel.a != 0)
				destination->p[x2 + y2*destination->w] = source_pixel;
		}
	}
}

#pragma pop_macro ("max")
#pragma pop_macro ("min")